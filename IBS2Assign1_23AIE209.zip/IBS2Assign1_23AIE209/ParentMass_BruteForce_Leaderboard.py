amino_mass={'G':57,'A':71,'S':87,'P':97,'V':99,'T':101,'C':103,'I':113,'L':113,'N':114,'D':115,'K':128,'Q':128,'E':129,'M':131,'H':137,'F':147,'R':156,'Y':163,'W':186}

parent_mass=128

result=[]

def generate(peptide,mass):
    if mass==parent_mass:
        result.append(peptide)
        return
    if mass>parent_mass:
        return
    for a in amino_mass:
        generate(peptide+a,mass+amino_mass[a])

generate("",0)

print("Without Leaderboard")
for p in result:
    print(p)

leaderboard=[""]
leader_peptides=[]

while leaderboard:
    new_board=[]
    for peptide in leaderboard:
        for a in amino_mass:
            new_peptide=peptide+a
            mass=sum(amino_mass[x] for x in new_peptide)
            if mass==parent_mass:
                leader_peptides.append(new_peptide)
            if mass<=parent_mass:
                new_board.append(new_peptide)
    leaderboard=new_board[:20]

print("With Leaderboard")
for p in leader_peptides:
    print(p)
